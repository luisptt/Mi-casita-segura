package com.example.Mi.casita.segura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiCasitaSeguraApplicationTests {

	@Test
	void contextLoads() {
	}

}
